package lab10;

import static org.junit.Assert.*;

import org.junit.Test;

pimport org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * 
 */

    @Test
    public void testGetId() {
        System.out.println("getId");
        fileObjectPojo instance = new fileObjectPojo();
        int expResult = 0;
        int result = instance.getId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setId method, of class fileObjectPojo.
     */
    @Test
    public void testSetId() {
        System.out.println("setId");
        int id = 0;
        fileObjectPojo instance = new fileObjectPojo();
        instance.setId(id);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFileName method, of class fileObjectPojo.
     */
    @Test
    public void testGetFileName() {
        System.out.println("getFileName");
        fileObjectPojo instance = new fileObjectPojo();
        String expResult = "";
        String result = instance.getFileName();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setFileName method, of class fileObjectPojo.
     */
    @Test
    public void testSetFileName() {
        System.out.println("setFileName");
        String file_name = "";
        fileObjectPojo instance = new fileObjectPojo();
        instance.setFileName(file_name);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getHashValue method, of class fileObjectPojo.
     */
    @Test
    public void testGetHashValue() {
        System.out.println("getHashValue");
        fileObjectPojo instance = new fileObjectPojo();
        String expResult = "";
        String result = instance.getHashValue();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setHashValue method, of class fileObjectPojo.
     */
    @Test
    public void testSetHashValue() {
        System.out.println("setHashValue");
        String hashValue_n = "";
        fileObjectPojo instance = new fileObjectPojo();
        instance.setHashValue(hashValue_n);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
