package lab10;

import java.io.File;
import java.util.List; 
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator; 
import java.util.Scanner;
 
import org.hibernate.HibernateException; 
import org.hibernate.Session; 
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class application_test{
   private static SessionFactory factory; 
   public static int check;
   public static int report = 0;
   public static void main(String[] args) {
      try{
         factory = new Configuration().configure().buildSessionFactory();
      }catch (Throwable ex) { 
         System.err.println("Failed to create sessionFactory object." + ex);
         throw new ExceptionInInitializerError(ex); 
      }
      application_testME = new application();

   
      /* Add few objects records in database */
      source l = new source();
      
      HashMap<File , String> orm = source.orm;
      int i=0;
      while(i<orm.size())
    {
      Integer fileID1 = ME.addfileObjectPojo(orm.get(i),orm.get(i));
      Integer fileID2 = ME.addfileObjectPojo(orm.get(i), orm.get(i));
      Integer fileID3 = ME.addfileObjectPojo(orm.get(i), orm.get(i));
      i++;
      }
      /* List down all the fileObjectPojo */
      ME.retrievefileObjectPojos("");

     
      /* List down new list of the fileObjectPojo */
      ME.retrievefileObjectPojos("");
      
      
   }
   public void retrievefileObjectPojos( String s){
	      Session session = factory.openSession();
	      Transaction tx = null;
	      try{
	         tx = session.beginTransaction();
	         List fileObjectPojo = session.createQuery("FROM fileObjectPojo").list(); 
	         for (Iterator iterator = 
	                           fileObjectPojo.iterator(); iterator.hasNext();){
	            fileObjectPojo fileObjectPojo2 = (fileObjectPojo) iterator.next(); 
	            System.out.print("File Name: " + fileObjectPojo2.getFileName()); 
	            System.out.print("  hash value: " + fileObjectPojo2.getHashValue()); 
	        
	         }
	         tx.commit();
	      }catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      }finally {
	         session.close(); 
	      }
	   }
   
   public void SetupPassiveMonotoring(application_testME){
	    
	    System.out.println("Do you want to continue press -1 to exit else other key\n");
	    Scanner scan = new Scanner(System.in);
	    int s2 = scan.nextInt();
	    
	    while(s2!=-1){
	         System.out.println("Do you want to continue press -1 to exit else other key\n");
	        s2 = scan.nextInt();
	        
	    System.out.println("Enter changed file name\n");
	    String s = scan.next();

	ME.retrievefileObjectPojos(s);


	if(check==0){

	System.out.println("contents are modified using passive monitoring ");
	System.out.println("Your file is change "+ s);
	report+=1;
	}

	}
	     System.out.println("Integrity violation report\n");
	  System.out.println("Total files modified are \n" + report );
	}
   /* Method to CREATE an fileObjectPojo2 in the database */
   public Integer addfileObjectPojo(String fileName, String hashValue){
      Session session = factory.openSession();
      Transaction tx = null;
      Integer fileValue = null;
      try{
         tx = session.beginTransaction();
         fileObjectPojo fileObjectPojo2 = new fileObjectPojo(fileName, hashValue);
         fileValue = (Integer) session.save(fileObjectPojo2); 
         tx.commit();
      }catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace(); 
      }finally {
         session.close(); 
      }
      return fileValue;
   }
   /* Method to  READ all the fileObjectPojo */
   


}
