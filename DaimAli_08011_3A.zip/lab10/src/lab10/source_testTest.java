package source;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({source.fileObjectPojoTest.class, source.Test.class, source.applicationt.class})
public class source_testTest {

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }
    
}

