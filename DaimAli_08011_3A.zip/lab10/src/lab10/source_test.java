package lab10;

import java.io.File;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * 
 */
public class source_test {
    
    public source_test() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of sha1 method, of class source.
     */
    @Test
    public void testSha1() throws Exception {
        System.out.println("sha1");
        File folder = new File("C:\\Users\\dali.bscs13seecs\\Desktop\\directory");
    File[] list_files = folder.listFiles();

        String expected_result = "aefjdkafj34343kfjadkf";
        String output = source.sha1(list_files[0]);
        assertEquals(expected_result, output);
        // TODO review the generated test code and remove the default call to fail.
       
    }

    /**
     * Test of main method, of class source.
     */
    @Test
    public void testMain() throws Exception {
        System.out.println("main");
        String[] args = null;
        source.main(args);
        
        fail("The test case is a prototype.");
    }
    
}
