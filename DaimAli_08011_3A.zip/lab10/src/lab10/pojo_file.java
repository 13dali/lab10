package lab10;

public class pojo_file {
    
	   
	   private int id;
	   private String fileName; 
	   private String hashValue;   
	  
	   public pojo_file() {}
	   public pojo_file(String dir_name, String value_hash) {
	      this.fileName = dir_name;
	      this.hashValue = value_hash;
	    }
	   public void setHashValue( String hashValue_n ) {
		      this.hashValue = hashValue_n;
		   }
	   
	   
	   public String getFileName() {
		      return fileName;
		   }
		   public void setFileName( String file_name ) {
		      this.fileName = file_name;
		   }
	   public int getId() {
	      return id;
	   }
	   public void setId( int id ) {
	      this.id = id;
	   }
	   
	   public String getHashValue() {
	      return hashValue;
	   }
	   
	}
