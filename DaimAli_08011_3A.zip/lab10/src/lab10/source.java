package lab10;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * 
 */
public class source {

  public static  HashMap<File , String> hm = new HashMap<File, String>();
    /**
     * @param args the command line arguments
     */
     public static String sha1(final File file) throws NoSuchAlgorithmException, IOException {
    final MessageDigest messageDigest = MessageDigest.getInstance("SHA1");

    try (InputStream is = new BufferedInputStream(new FileInputStream(file))) {
      final byte[] store = new byte[1024];
      int read=0;
      while((read = is.read(store)) != -1) {
        messageDigest.update(store, 0, read);
      }
    }

    // Convert the byte to hex format
    try (Formatter remove = new Formatter()) {
      for (final byte b : messageDigest.digest()) {
        remove.format("%02x", b);
      }
      return remove.toString();
    }
  }
    
     
     
     
    public static void main(String[] args) throws NoSuchAlgorithmException {
        // TODO code application logic here
       //calculate the hashmap of all the file objects and storin in map 
    File dir_file = new File("C:\\Users\\dali.bscs13seecs\\Desktop\\directory");
    File[] files_list = dir_file.listFiles();
    
    int i=0;
    while(i < files_list.length) {
      if (files_list[i].isFile()) {
        System.out.println("File " + files_list[i].getName());
      } else if (files_list[i].isDirectory()) {
        System.out.println("Directory " + files_list[i].getName());
      }
      i++;
    }   
         
         

         try {  
        	 int j=0;
        	 while(j < files_list.length) {   
        hm.put(files_list[j],sha1(files_list[j]) );
        System.out.println(hm.get(files_list[j]));
          j++;
          }
             
             
         } catch (Exception ex) {
             Logger.getLogger(source.class.getName()).log(Level.SEVERE, null, ex);
         }
         
        
    }
    
}
